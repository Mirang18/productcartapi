package com.adapty.shopping.entities;

public enum CATEGORY {
    CLOTHS,
    ELECTRONICS,
    FOOD_PRODUCTS,
    BOOKS,
    FURNITURE,
    TOYS

}
