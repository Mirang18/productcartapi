package com.adapty.shopping.entities;

public enum STATUS {

    ACTIVE,
    INACTIVE
}
